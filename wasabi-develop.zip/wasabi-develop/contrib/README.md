# Contribute Projects, Plugins, and Apps to Wasabi!

**Add your contributing project to the contrib directory:**

```bash

wasabi/contrib/[your-project-name]/[your-project-structure]

wasabi/contrib/hello-world

```
